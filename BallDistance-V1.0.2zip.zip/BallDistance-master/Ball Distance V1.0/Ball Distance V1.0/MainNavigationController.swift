//
//  MainNavigationController.swift
//  Ball Distance V1.0
//
//  Created by Owen Thurm on 12/28/18.
//  Copyright © 2018 Cam Cross. All rights reserved.
//

import Foundation
import UIKit

class MainNavigationController: UINavigationController
{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
}
