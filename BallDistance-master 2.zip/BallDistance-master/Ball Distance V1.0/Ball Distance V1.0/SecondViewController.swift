//
//  SecondViewController.swift
//  Ball Distance V1.0
//
//  Created by Cam Cross on 12/28/18.
//  Copyright © 2018 Cam Cross. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

